# Gojo Tech + Supabase

## Estructura
- `index.html`: marcado de la página
- `css/styles.css`: diseño verde/azul, fondo de lámpara de lava y detalles dorados del admin
- `js/config.js`: URL y clave **pública** de Supabase (lo único que debes editar)
- `js/app.js`: lógica de la tienda, pedidos y panel de administrador
- `supabase/schema.sql`: tablas, RLS, triggers, Storage y tiempo real

## Pasos
1. Crea un proyecto en supabase.com.
2. **SQL Editor**: pega y ejecuta todo `supabase/schema.sql`.
3. **Authentication > Sign In / Providers**: activa **Allow anonymous sign-ins** (cada visitante recibe una identidad anónima para que sus pedidos sean solo suyos).
4. **Authentication > Users > Add user**: crea el correo y la contraseña del administrador (marca "Auto confirm").
5. En el SQL Editor ejecuta (con tu correo):
   `insert into public.admins (user_id) select id from auth.users where email = 'TU-CORREO@ejemplo.com';`
6. **Project Settings > API**: copia la *Project URL* y la clave *anon / publishable* en `js/config.js`. No uses nunca la `service_role`.
7. Publica la carpeta en cualquier hosting estático (Netlify, Vercel, GitHub Pages, Cloudflare Pages). En **Authentication > URL Configuration** agrega esa dirección. Para probar en local: `npx serve gojo-tech`.

## Seguridad (resumen)
- **productos**: lectura pública de los activos; solo el administrador crea, modifica y borra.
- **pedidos**: cada usuario ve, crea y modifica solo los suyos, y solo mientras estén pendientes. Solo puede cambiarlos a Cancelado. Nadie borra pedidos.
- **El servidor decide** dueño, estado inicial, código único y precio (triggers), así que modificar el JavaScript no sirve para saltarse las reglas.
- **administrador**: se valida con Supabase Auth y la tabla `admins`, no con una contraseña en el código.
- **Storage**: solo el administrador sube y borra imágenes (carpeta `productos/`).
